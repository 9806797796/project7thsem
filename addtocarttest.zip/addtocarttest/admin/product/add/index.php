<?php
session_start();
	if(isset($_POST['submit'])){
		$name  = $_POST['name'];
		$cost  = $_POST['cost'];
		$detail = $_POST['detail'];

		$filename = $_FILES["photo"]["name"];
	    $tempname = $_FILES["photo"]["tmp_name"];
	    $folder = "../../../img/" . $filename;

		include('../../../connection.php'); 
		
		$addstatement = "INSERT INTO products(name, cost, photo, detail) VALUES ('$name', '$cost', '$filename', '$detail')";
		
		mysqli_query($conn, $addstatement);
		   move_uploaded_file($tempname, $folder);
		header("Location: index.php"); 

	}
	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Product</title>
</head>
<body>
	<h1>Add Product</h1>
	<form action="" method="POST" enctype="multipart/form-data">
		Product Name : <input type="text" name="name" required> <br />
		Product Cost : <input type="number" name="cost" required> <br />
		Product Detail : <textarea name="detail"></textarea required> <br />
		Photo : <input type="file" name="photo" required> <br />
		<input type="submit" name="submit">
	</form>

</body>
</html>