<?php
session_start();
 unset($_SESSION['cartcode']);
  header("Location: template.php?page=home&message=clear your Cart");
?>  
