<?php
session_start();

//add to productid
$product_name  = $_POST['product_name'];
$product_detail = $_POST['product_detail'];
$product_cost = $_POST['product_cost'];
$productid=$_GET['id']; /*product ko detail taneko*/
$getproductstatement="SELECT * FROM products where id='$productid' LIMIT 1"; 
		include('connection.php'); 	
		$result1=mysqli_query($conn, $getproductstatement);
		$result = mysqli_fetch_row($result1);

// $_SESSION["cartcode"] = 'abc';
// echo $_SESSION['cartcode'];
if(isset($_SESSION['cartcode'])){
		  
		$cartcode = $_SESSION['cartcode'];
		$addtocartstatement = "INSERT INTO carts(product_id, cost, qty, cartcode, totalamount ) VALUES ('$result[0]', '$result[3]', '1', '$cartcode', '$result[3]')";
		
		mysqli_query($conn, $addtocartstatement); 

 }
 else{
 	$makecartcode = substr(str_shuffle("0123456789abcdefghijklmnopqrstvwxyz"), 0, 6);/*yadi session xaena vane yo print huni vayo xa vane if wala print hunivayo*/
 	// echo $makecartcode;
 	$_SESSION["cartcode"] = $makecartcode;
// database ko taneko
 	$addtocartstatement = "INSERT INTO carts(product_id, cost, qty, cartcode, totalamount) VALUES ('$result[0]', '$result[3]', '1', '$makecartcode', '$result[3]')";
		
		mysqli_query($conn, $addtocartstatement);

 }
 header("Location: template.php?page=cart&message=Your Product Save into  Cart");
 ?>
