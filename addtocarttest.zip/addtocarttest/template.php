<?php
session_start();
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Ladies Kurtha</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
	
</head>
<body>
	
<section id="topheader" style="background: black; padding: 100px 0;">
	<div class="container">
		<div class="row">
			<div class="col-md-12" style="color: #fff; text-align: right;">
				
				</br>
				<!-- clear cart delete ko lagi -->
				
				
				<a href="template.php?page=home" class="btn btn-primary"> Home</a>

				
				<?php if(isset($_SESSION['wishlist'])): ?>
					<?php $countwishlist = count($_SESSION['wishlist']); ?>
				<a href="template.php?page=wishlist" class="btn btn-primary"> <i class="fa-solid fa-heart"></i> Wish List (<?php echo $countwishlist; ?>)</a>

				<?php endif ?>
				
				<?php if(isset($_SESSION['cartcode'])): ?>
					<?php
					$cardcode = $_SESSION['cartcode'];

					$getcart  = "SELECT * FROM carts WHERE cartcode='$cardcode'";
					$cart = mysqli_query($conn, $getcart);
					$row = mysqli_num_rows($cart);
					?>
					<a href="template.php?page=cart" class="btn btn-primary"><i class="fa-solid fa-cart-shopping"></i> View Cart (<?php echo $row ?> items)</a>
				<?php endif ?>
				
			</div>
			
			
		</div>
		<div class="row">
			<div class="col-md-12">
				<br />
				<?php
			if(isset($_GET['message'])){
				echo '<br /><div class="alert alert-primary" role="alert">'.$_GET['message'].'</div>';
			}

			?>
				
			</div>
		</div>
		
		<?php
			if(isset($_GET['page'])){
				$page = $_GET['page'];
				
				include 'page/'.$page.'.php';
			}
			else{
				include'page/home.php';
			}

		?>
			
		
	

	</div>
</section>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap/js/all.js"></script>
<script type="text/javascript" src="fontawesome/js/all.js"></script>
</body>
</html>
