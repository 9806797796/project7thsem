<?php
session_start();
		include('connection.php'); 
		$cartcode = $_SESSION['cartcode'];	
		$sql="SELECT * FROM carts WHERE cartcode='$cartcode'"; 
		$result=mysqli_query($conn, $sql);

		//  grand total amount ko lagi
		$totalamount_sql = "SELECT  SUM(totalamount) from carts WHERE cartcode='$cartcode'";
		$totalamount_result=mysqli_query($conn, $totalamount_sql);
		$row1 = mysqli_fetch_array($totalamount_result);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>View Cart</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
</head>
<body>
	<section id="viewcart" style="padding: 30px 0;">
		<div class="container">
			<div class="row">
			<span style="color: darkcyan; font-style: italic;"> 	
				<h1> <i class="fa-solid fa-cart-shopping"></i> Your Cart</h1>
			</span>
	<table class="table">
		<tr>
			<th> Name</th>
			<th> Qty</th>
			<th> Cost</th>
			<th> Total</th>
		
			

		</tr>
		<?php foreach($result as $row): ?>
		<tr>
			<?php
				$pid = $row['product_id'];
				
				 include('connection.php'); 
				
				$sql2="SELECT * FROM products WHERE id='$pid'"; 
				
				$result2=mysqli_query($conn, $sql2);

				$row2 = mysqli_fetch_array($result2);

			?>
			<td> <?php 	echo $row2['name']; ?></td>
			<td> <?php 	echo $row['qty']; ?></td>
			<td> <?php 	echo $row['cost']; ?></td>
			<td> <?php 	echo $row['totalamount']; ?></td>
			
		</tr>
	<?php endforeach ?>
		
		<tr>
			<td colspan="3" style="font-weight:bold; text-align:right;"> Grand Total :</td>
			<td style="font-weight: bold;"> <?php 	echo $row1[0]; ?></td>
			
		</tr>
	</table>
	<a href="deletecart.php" class="btn btn-primary" style="background-color: darkcyan;">Clear Cart</a> &nbsp; &nbsp;
	<a href="template.php" class="btn btn-primary" style="background-color: darkcyan;">Continous Shopping</a> &nbsp; &nbsp;
	<a href="checkout.php" class="btn btn-primary" style="background-color: darkcyan;">Checkout</a> &nbsp; &nbsp;


	

			</div>
		</div>
	<form action="https://uat.esewa.com.np/epay/main" method="POST">
    <input value="<?php echo $row1[0]; ?>" name="tAmt" type="hidden">
    <input value="<?php echo $row1[0]; ?>" name="amt" type="hidden">
    <input value="0" name="txAmt" type="hidden">
    <input value="0" name="psc" type="hidden">
    <input value="0" name="pdc" type="hidden">
    <input value="EPAYTEST" name="scd" type="hidden">
    <input value="testing-1234" name="pid" type="hidden">
    <input value="http://localhost/addtocarttest/paymentstatus.php?q=su" type="hidden" name="su">
    <input value="http://localhost/addtocarttest/paymentstatus.php?q=fu" type="hidden" name="fu">
    <input class="btn btn-primary" value="Pay via eSewa" type="submit">
    </form>
	</section>
 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap/js/all.js"></script>
<script type="text/javascript" src="fontawesome/js/all.js"></script>
</body>
</html>