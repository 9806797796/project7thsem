<h1>Check Out </h1>
<form>
	Name : <input type="text" name="name"><br />
	Shiiping Address: <input type="text" name="address"><br />
	Email : <input type="email" name="email"><br />
	Mobile : <input type="number" name="mobile"><br /> 
	<input type="submit" name="Checkout">
</form>