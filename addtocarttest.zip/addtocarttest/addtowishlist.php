<?php
session_start();
$productid  = $_GET['id'];
if(!isset($_SESSION['wishlist'])){
	$_SESSION['wishlist']=array();
}
else{
	$_SESSION['wishlist'][]= $productid;
}


 header("Location: template.php?page=wishlist&message=Product Save on Wishlist");

 ?>