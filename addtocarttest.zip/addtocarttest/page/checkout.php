<?php

		include('connection.php'); 
		$cartcode = $_SESSION['cartcode'];	
		$sql="SELECT * FROM carts WHERE cartcode='$cartcode'"; 
		$result=mysqli_query($conn, $sql);

		//  grand total amount ko lagi
		$totalamount_sql = "SELECT  SUM(totalamount) from carts WHERE cartcode='$cartcode'"; 
		$totalamount_result=mysqli_query($conn, $totalamount_sql);
		$row1 = mysqli_fetch_array($totalamount_result);
?>
	<?php
	if(isset($_POST['submit'])){
		$name  = $_POST['name'];
		$address  = $_POST['address'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		include('connection.php'); 
		$cartcode = $_SESSION['cartcode'];
		$order_date = date('Y-m-d');
		$addstatement = "INSERT INTO orders(cartcode, name, address, email, mobile, order_date ) VALUES ('$cartcode', '$name', '$address', '$email', '$mobile', '$order_date')";
		
		mysqli_query($conn, $addstatement);
		header("Location: template.php?page=payment"); 

	}
	?>
	<div class="row">
		<div class="col-md-12" style="text-align:center;">
			<h1 style="color:#fff">Checkout</h1>
		</div>
	</div>
	<div class="row">
		<form action="template.php?page=checkout" class="form" style="color:#fff" method="POST">
			Name : <input class="from-control" type="text" name="name" required><br /><br />
			Shiiping Address: <input type="text" name="address" required><br /><br />
			Email : <input type="email" name="email" required><br /><br />
			Mobile : <input type="number" name="mobile" required><br />  <br />
			<input name="submit" type="submit" name="Checkout">
		</form>
	</div>