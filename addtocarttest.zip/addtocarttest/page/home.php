<?php 
		include('connection.php'); 	
		$sql="SELECT * FROM products"; 
		$result=mysqli_query($conn, $sql);
		$row2 = $result->fetch_assoc();


 ?>
	<div class="row">
		<div class="col-md-12" style="text-align:center;"> 
			<h1 style="color:#fff">Our Product</h1>
		</div>
	</div>
	<div class="row">
		<?php foreach($result as $key => $row): ?>
			<div class="col-md-4">
				<div class="card" style="width: 18rem;">
				  	<img src="img/<?php 	echo $row['photo']; ?>" class="card-img-top" alt="...">
					<div class="card-body">
					    <h5 class="card-title"><?php 	echo $row['name']; ?></h5>
					    <span style="color: red;">
					    		<h4>Rs. <?php 	echo $row['cost']; ?> </h4>
					    </span>

					    <p class="card-text"><?php 	echo $row['detail']; ?></p>
					    
					     <a href="addtowishlist.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Wish List</a>
					     <a href="addtocart.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Add To Cart</a>
					    <br /> <br />
					</div>
				</div>
			</div>
		<?php 	endforeach ?>
	</div>