<?php

		include('connection.php'); 
		$cartcode = $_SESSION['cartcode'];	
		$sql="SELECT * FROM carts WHERE cartcode='$cartcode'"; 
		$result=mysqli_query($conn, $sql);

		//  grand total amount ko lagi
		$totalamount_sql = "SELECT  SUM(totalamount) from carts WHERE cartcode='$cartcode'";
		$totalamount_result=mysqli_query($conn, $totalamount_sql);
		$row1 = mysqli_fetch_array($totalamount_result);

		$getordersql="SELECT * FROM orders WHERE cartcode='$cartcode'";
		$resulordert=mysqli_query($conn, $getordersql);
		$shippinginfo = mysqli_fetch_array($resulordert);
?>
	<div class="row">
		<div class="col-md-12" style="text-align:center;">
			<h1 style="color:#fff">Your Order</h1>
		</div>
	</div>
	<div class="row">
		<table class="table" style="color:#fff">
		<tr>
			<th> Name</th>
			<th> Qty</th>
			<th> Cost</th>
			<th> Total</th>
		
			

		</tr>
		<?php foreach($result as $row): ?>
		<tr>
			<?php
				$pid = $row['product_id'];
				
				 include('connection.php'); 
				
				$sql2="SELECT * FROM products WHERE id='$pid'"; 
				
				$result2=mysqli_query($conn, $sql2);

				$row2 = mysqli_fetch_array($result2);

			?>
			<td> <?php 	echo $row2['name']; ?></td>
			<td> <?php 	echo $row['qty']; ?></td>
			<td> <?php 	echo $row['cost']; ?></td>
			<td> <?php 	echo $row['totalamount']; ?></td>
			
		</tr>
	<?php endforeach ?>
		
		<tr>
			<td colspan="3" style="font-weight:bold; text-align:right;"> Grand Total :</td>
			<td style="font-weight: bold;"> <?php 	echo $row1[0]; ?></td>
			
		</tr>
	</table>
	
	</div>
	<div class="row" style="color:#fff">
		<div class="col-md-6">
			<h3>Shipping Information</h3>
			Name : <?php echo $shippinginfo['name']; ?> <br />
			address : <?php echo $shippinginfo['address']; ?> <br />
			Mobile Number : <?php echo $shippinginfo['mobile']; ?> <br />
			Email : <?php echo $shippinginfo['email']; ?> <br />
		</div>
		<div class="col-md-6">
			<h3>Payment</h3>
			<h1>Rs.  <?php 	echo $row1[0]; ?></h1>
			<form action="https://uat.esewa.com.np/epay/main" method="POST">
    <input value="<?php echo $row1[0]; ?>" name="tAmt" type="hidden">
    <input value="<?php echo $row1[0]; ?>" name="amt" type="hidden">
    <input value="0" name="txAmt" type="hidden">
    <input value="0" name="psc" type="hidden">
    <input value="0" name="pdc" type="hidden">
    <input value="EPAYTEST" name="scd" type="hidden">
    <input value="testing-1234" name="pid" type="hidden">
    <input value="http://localhost/addtocarttest/paymentstatus.php?q=su" type="hidden" name="su">
    <input value="http://localhost/addtocarttest/paymentstatus.php?q=fu" type="hidden" name="fu">
    <img src="img/esewa.png" width="180">
    <input class="btn btn-primary" value="Pay via eSewa" type="submit">
    </form>
		</div>
	</div>
