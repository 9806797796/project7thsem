<div class="row">
	<div class="col-md-12" style="text-align:center">
		<h2 style="color:#fff">Your Wishist</h2>
	</div>
</div>
<div class="row">
	<table class="table" style="color: #fff"> 
		<tr>
			<th> ID</th>
			<th>Product Name</th>
			<th>Cost</th>
		</tr>
		<?php
		for($i = 0 ; $i < count($_SESSION['wishlist']) ; $i++){
		 echo '<tr><td>'.$_SESSION['wishlist'][$i].'</td>';
		 $productdd = $_SESSION['wishlist'][$i];
		 include('connection.php'); 
		
		$sql="SELECT * FROM products WHERE id='$productdd'"; 
		$result=mysqli_query($conn, $sql);
		$row1 = mysqli_fetch_array($result);
		echo '<td>'.$row1['name'].'</td><td> Rs. '.$row1['cost'].'</td></tr>';
	}
	?>
	<?php

	?>
		
		
	</table>
	<a href="clearwishlist.php" class="btn btn-primary" style="background-color: darkcyan;">Clear Wish list</a> &nbsp; &nbsp;
</div>