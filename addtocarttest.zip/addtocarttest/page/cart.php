<?php

		include('connection.php'); 
		$cartcode = $_SESSION['cartcode'];	
		$sql="SELECT * FROM carts WHERE cartcode='$cartcode'"; 
		$result=mysqli_query($conn, $sql);

		//  grand total amount ko lagi
		$totalamount_sql = "SELECT  SUM(totalamount) from carts WHERE cartcode='$cartcode'";
		$totalamount_result=mysqli_query($conn, $totalamount_sql);
		$row1 = mysqli_fetch_array($totalamount_result);
?>
	<div class="row">
		<div class="col-md-12" style="text-align:center;">
			<h1 style="color:#fff">Cart</h1>
		</div>
	</div>
	<div class="row">
		<table class="table" style="color:#fff">
		<tr>
			<th> Name</th>
			<th> Qty</th>
			<th> Cost</th>
			<th> Total</th>
		
			

		</tr>
		<?php foreach($result as $row): ?>
		<tr>
			<?php
				$pid = $row['product_id'];
				
				 include('connection.php'); 
				
				$sql2="SELECT * FROM products WHERE id='$pid'"; 
				
				$result2=mysqli_query($conn, $sql2);

				$row2 = mysqli_fetch_array($result2);

			?>
			<td> <?php 	echo $row2['name']; ?></td>
			<td> <?php 	echo $row['qty']; ?></td>
			<td> <?php 	echo $row['cost']; ?></td>
			<td> <?php 	echo $row['totalamount']; ?></td>
			
		</tr>
	<?php endforeach ?>
		
		<tr>
			<td colspan="3" style="font-weight:bold; text-align:right;"> Grand Total :</td>
			<td style="font-weight: bold;"> <?php 	echo $row1[0]; ?></td>
			
		</tr>
	</table>
	<a href="deletecart.php" class="btn btn-primary" style="background-color: darkcyan;">Clear Cart</a> &nbsp; &nbsp;
	<a href="template.php?page=home" class="btn btn-primary" style="background-color: darkcyan;">Continous Shopping</a> &nbsp; &nbsp;
	<a href="template.php?page=checkout" class="btn btn-primary" style="background-color: darkcyan;">Checkout</a> &nbsp; &nbsp;
	</div>