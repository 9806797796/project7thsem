<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>View Cart</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
</head>
<body>
	<section id="viewcart" style="padding: 30px 0;">
		<div class="container">
			<div class="row">
			<span style="color: darkcyan; font-style: italic;"> 	
				<h1> <i class="fa-solid fa-cart-shopping"></i> Your Wish List</h1>
			</span>
	<table class="table">
		<tr>
			<th> ID</th>
			<th>Product Name</th>
			<th>Cost</th>
		</tr>
		<?php
		for($i = 0 ; $i < count($_SESSION['wishlist']) ; $i++){
		 echo '<tr><td>'.$_SESSION['wishlist'][$i].'</td>';
		 $productdd = $_SESSION['wishlist'][$i];
		 include('connection.php'); 
		
		$sql="SELECT * FROM products WHERE id='$productdd'"; 
		$result=mysqli_query($conn, $sql);
		$row1 = mysqli_fetch_array($result);
		echo '<td>'.$row1['name'].'</td><td> Rs. '.$row1['cost'].'</td></tr>';
	}
	?>
	<?php

	?>
		
		
	</table>
	<a href="clearwishlist.php" class="btn btn-primary" style="background-color: darkcyan;">Clear Wish list</a> &nbsp; &nbsp;
	
			</div>
		</div>
		
	</section>
 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="bootstrap/js/all.js"></script>
<script type="text/javascript" src="fontawesome/js/all.js"></script>
</body>
</html>