<?php
session_start();
unset($_SESSION['wishlist']);
  header("Location: template.php?page=home&message=clear your wish list");
?>